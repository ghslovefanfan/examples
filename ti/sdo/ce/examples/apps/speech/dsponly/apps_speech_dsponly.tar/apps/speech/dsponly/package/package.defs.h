#ifndef apps_speech_dsponly__
#define apps_speech_dsponly__

#endif /* apps_speech_dsponly__ */ 
